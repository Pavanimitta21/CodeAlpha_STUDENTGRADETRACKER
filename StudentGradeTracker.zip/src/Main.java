import java.util.ArrayList;
import java.util.Scanner;

class Student {
    private String name;
    private ArrayList<Integer> grades;

    public Student(String name) {
        this.name = name;
        this.grades = new ArrayList<>();
    }

    public void addGrade(int grade) {
        grades.add(grade);
    }

    public String getName() {
        return name;
    }

    public ArrayList<Integer> getGrades() {
        return grades;
    }

    public double getAverage() {
        if (grades.isEmpty()) return 0.0;
        int sum = 0;
        for (int g : grades) {
            sum += g;
        }
        return (double) sum / grades.size();
    }

    public int getHighest() {
        if (grades.isEmpty()) return 0;
        int max = grades.get(0);
        for (int g : grades) {
            if (g > max) max = g;
        }
        return max;
    }

    public int getLowest() {
        if (grades.isEmpty()) return 0;
        int min = grades.get(0);
        for (int g : grades) {
            if (g < min) min = g;
        }
        return min;
    }
}

public class Main {
    private static ArrayList<Student> students = new ArrayList<>();
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;
        do {
            System.out.println("\n===== Student Grade Tracker =====");
            System.out.println("1. Add Student");
            System.out.println("2. Add Grade to Student");
            System.out.println("3. View Student Report");
            System.out.println("4. View All Students Summary");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> addStudent();
                case 2 -> addGrade();
                case 3 -> viewStudentReport();
                case 4 -> viewAllSummary();
                case 5 -> System.out.println("Exiting... Thank you!");
                default -> System.out.println("Invalid choice! Try again.");
            }
        } while (choice != 5);
    }

    private static void addStudent() {
        System.out.print("Enter student name: ");
        String name = sc.nextLine();
        students.add(new Student(name));
        System.out.println("✅ Student added successfully.");
    }

    private static void addGrade() {
        if (students.isEmpty()) {
            System.out.println("No students found! Add a student first.");
            return;
        }
        System.out.print("Enter student name: ");
        String name = sc.nextLine();
        Student student = findStudent(name);
        if (student != null) {
            System.out.print("Enter grade (0-100): ");
            int grade = sc.nextInt();
            sc.nextLine();
            student.addGrade(grade);
            System.out.println("✅ Grade added.");
        } else {
            System.out.println("❌ Student not found!");
        }
    }

    private static void viewStudentReport() {
        System.out.print("Enter student name: ");
        String name = sc.nextLine();
        Student student = findStudent(name);
        if (student != null) {
            System.out.println("\n--- Report for " + student.getName() + " ---");
            System.out.println("Grades: " + student.getGrades());
            System.out.println("Average: " + student.getAverage());
            System.out.println("Highest: " + student.getHighest());
            System.out.println("Lowest: " + student.getLowest());
        } else {
            System.out.println("❌ Student not found!");
        }
    }

    private static void viewAllSummary() {
        if (students.isEmpty()) {
            System.out.println("No students available!");
            return;
        }
        System.out.println("\n===== Summary Report =====");
        for (Student s : students) {
            System.out.println("Student: " + s.getName());
            System.out.println("Grades: " + s.getGrades());
            System.out.println("Average: " + s.getAverage());
            System.out.println("Highest: " + s.getHighest());
            System.out.println("Lowest: " + s.getLowest());
            System.out.println("-----------------------------");
        }
    }

    private static Student findStudent(String name) {
        for (Student s : students) {
            if (s.getName().equalsIgnoreCase(name)) {
                return s;
            }
        }
        return null;
    }
}
