# Student Grade Tracker

## Features
- Add students and their grades.
- Calculate average, highest, and lowest scores.
- View individual and summary reports.

## How to Run
1. Open this folder in VS Code.
2. Open terminal and run:
   ```bash
   javac src/Main.java
   java -cp src Main
   ```
